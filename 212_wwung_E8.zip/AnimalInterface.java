//package animals;

public interface AnimalInterface {
	public void store(Animal animal);
	public long calcScore() throws InedibleException;
	
}
