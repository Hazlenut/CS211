//package animals;

public class InedibleException extends Exception{
	public InedibleException(String s) {
		super(s);
	}
}
